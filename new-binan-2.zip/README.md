# new-binan-2

币安快速抽插

```json
{
  "api": "api",
  "secret": "secret",
  "proxy": "http://127.0.0.1:1080",
  "debug": true
}
```